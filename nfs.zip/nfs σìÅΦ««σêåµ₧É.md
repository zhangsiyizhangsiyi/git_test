[TOC]

---

## 特殊记录 ， 需要后续验证

Nfs3 上传文件时 CREATE CALL 	where中 有dir 有filename ， 若只创建文件夹会怎么样？
														若 上传的文件 ，在nfs3 服务器中已经有同名文件，会怎么样？

## nfs 协议分析

​				***nfs3协议不支持 用户名密码验证登录。与之相反 ， nfs4协议支持*** 

### **NFS的通信协议以RPC为基础操作⽅式**

#### ***调⽤响应报⽂的格式***

- λ	**Fragment header 报文长度  <u>Fragment header + sizeof(char) * 4 == tcp.payload.len</u>**
- λ	**XID (四字节)：这是RPC报⽂的编号，取值与请求报⽂中的XID⼀致，客户端靠这个字段分配应答消息对应哪次RPC请求。**
- λ	**Message Type （四字节）：RPC消息类型，这⾥取值为1，表⽰应答消息。**
- λ	**Reply State（四字节）： 是⼀个应答标志。当服务器端接收到RPC请求后会对报⽂格式进⾏检查，如果格式正确，是⼀个有效的RPC请求，则将Reply State设置为0，表⽰格式正确。**
- λ	**Verifier （多字节）：服务器端会解析RPC请求消息中的⽤户信息，对⽤户进⾏验证，根据结果填写Verifier字段，这个字段中包含了⾝份验证后的信息，这个字段和认证类型有关。**
- λ	**Accept State（四字节）： 这个字段表⽰服务器是否可以处理⼀个RPC请求，假如服务器不⽀持NFS服务，那么当接收到⼀个Program为100003的RPC消息后，就会拒绝这个请求。如果服务器中包含RPC消息中请求的处理程序，则接收这个请求。0表⽰接收请求，其他值表⽰不接收请求。**

![image-20230412162349497](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230412162349497.png)



#### ***调⽤请求报⽂的格式***

- λ	**Fragment header 报文长度  <u>Fragment header + sizeof(char) * 4 == payload.len</u>**

- λ	**XID （4字节）这是⼀个RPC报⽂的编号，每次递增1。**

  ​				**( 该值在请求和相应中一一对应 ， 每组request和respond ，使用的XID唯一 )**

- λ	**Message Type（4字节） 这是RPC报⽂的类型。RPC报⽂分为两种：请求消息⽤0表⽰，应答消息⽤1表⽰。上图是RPC请求报⽂的结构。**

- λ	**RPC Vlsersion （4字节）这是RPC协议本⾝的版本编号，⽬前通⽤的是版本2。**

- λ	**Program（4字节） 这是RPC程序编号。⽐如请求的是NFS服务，则这个字段为100003。**

- λ	**Version （4字节）这是RPC程序版本。⽐如请求的是NFSV2，则这个字段为2。**

- λ	**Procedure（4字节） 这是RPC例程编号。⽐如请求删除⼀个⽂件，则这个字段为10。**

- λ	**Credentials（多字节） 这是包含了⽤户信息，供服务器进⾏验证。RPC⽀持多种认证⽅式，不同认证⽅式中这个字段的内容不同。**

- λ	**Verifier （多字节）这是认证信息的验证值，这个字段也跟认证⽅式有关**

![image-20230412151103957](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230412151103957.png)

#### 指令类型

    //	rpc请求中 Procedure 就是nfs3 操作指令
    { 0,    "NULL" },
    { 1,    "GETATTR" },
    { 2,    "SETATTR" },
    { 3,    "LOOKUP" },
    { 4,    "ACCESS" },
    { 5,    "READLINK" },
    { 6,    "READ" },
    { 7,    "WRITE" },
    { 8,    "CREATE" },
    { 9,    "MKDIR" },
    { 10,   "SYMLINK" },
    { 11,   "MKNOD" },
    { 12,   "REMOVE" },
    { 13,   "RMDIR" },
    { 14,   "RENAME" },
    { 15,   "LINK" },
    { 16,   "READDIR" },
    { 17,   "READDIRPLUS" },
    { 18,   "FSSTAT" },
    { 19,   "FSINFO" },
    { 20,   "PATHCONF" },
    { 21,   "COMMIT" },
    { 0,    NULL }
    
    //	rpc请求中 Procedure 就是nfs4 操作指令
    { 0, "NULL" },
    { 1, "COMPOUND" },
    { 0, NULL }

---

---

### nfs007.pcapng	( 已整理完)

nfs007.pcapng 抓包时的动作是 ， 本地挂载远程目录后，从本地上传    "记录.docx"	 到远程

![image-20230420153336493](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230420153336493.png)

##### 文件传输过程分析	

```
nfs3 传输文件时，一直以文件句柄为标记，写入数据 ，不使用文件名	； 
			先获取	待传输文件 ，文件名和文件句柄的对应关系 ； 
						这样，传输文件时，才能确认 传输文件的文件名是什么 ； 
										在同一个nfs服务器，每个文件对应句柄 唯一 ； 
	
NFS协议中 XID在RPC层
XID是指交换标识符（Exchange Identifier），用于标识客户端和服务器之间，请求和响应之间的关系。
每个请求或响应都有一个唯一的XID
```

![image-20230423093844814](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423093844814.png)

​	分析有关RPC指令

​				<	分析 待传输文件		"记录.docx"		传输过程	>

​			LOOKUP	( no.242  ) 		[	no.250	再次请求获取文件句柄	但同no.242一样失败	] 

​						请求端	RPC指令 Procedure: LOOKUP (3)	-->	
​						记录请求端 **XID: 0xcb26583e (3408287806)** 【标记XID，等待对应响应端】--->
​						对应的 (NFS层) 记录 filename	 "记录.docx"	---> 
​						等待响应包返回 filename 对应的 Filehandle

​						响应端	等待	**XID: 0xcb26583e (3408287806)** --->
​						如果	(NFS层) Status: NFS3ERR_NOENT (2)
​						失败	说明，文件不存在	
​						丢弃	**XID: 0xcb26583e (3408287806)**  记录内容

​			CREATE	( no.254 )

​						请求端	Procedure: CREATE (8)	-->				
​						记录请求端 **XID: 0xcb265842 (3408287810)** 【标记等待对应响应端】--->
​						对应的 (NFS层) 记录 filename 	 "记录.docx"	--->

​						响应端	( no.256 ) 等待	**XID: 0xcb265842 (3408287810)**	---> 
​							---> 等待响应包返回 filename 对应的 Filehandle
​						如果	Status: NFS3_OK (0) 	--->
​						对应的 (NFS层) 记录 	--->	***Filehandle	[hash (CRC-32): 0x7b34bfaa]***
​							( 实际 Filehandle ，48字节 ，上面是 wireshark 自己做的哈希值，方便查看 )

```
create 中得到文件名，暂存，待 Status: NFS3_OK 时 存入 队列中，否则丢弃之，队列中不但要有filename，也要有XID ， destructor时 ，销毁 队列
```

请求端 遇到 CREATE CALL 
					记录请求端 XID: 0xcb265842	
					对应的 (NFS层) 记录 filename  
					CREATE CALL 动作
响应端 需要对每个  请求端 XID 进行对比验证 ， 确定是否是 	记录过的XID
								如果是 记录过的XID ， 进入对应 动作的处理 函数，分析数据
				例如是 CREATE 的响应 
								如果	Status: NFS3_OK (0) 	记录 NFS层 	--->	length 和 Filehandle	[hash (CRC-32): 0x7b34bfaa]
								如果	Status: 不是 NFS3_OK (0) 	 丢弃 刚才 CREATE CALL 获取的一切内容

| WRITE 指令 | WREITE Call                          | WRITE Replay      |
| ---------- | ------------------------------------ | ----------------- |
|            | no.523 XID: 0xcb265875 (3408287861)  | Replay in no.625  |
|            | no.554 XID: 0xcb265876 (3408287862)  | Replay in no.602  |
|            | no.581 XID: 0xcb265877 (3408287863)  | Replay in no.621  |
|            | no.612 XID: 0xcb265878 (3408287864)  | Replay in no.645  |
|            | no.640 XID: 0xcb265879 (3408287865)  | Replay in no.649  |
|            | no.669 XID: 0xcb26587a (3408287866)  | Replay in no.1137 |
|            | no.724 XID: 0xcb26587b (3408287867)  | Replay in no.958  |
|            | no.769 XID: 0xcb26587c (3408287868)  | Replay in no.1113 |
|            | no.809 XID: 0xcb26587d (3408287869)  | Replay in no.1115 |
|            | no.850 XID: 0xcb26587e (3408287870)  | Replay in no.1135 |
|            | no.889 XID: 0xcb26587f (3408287871)  | Replay in no.1118 |
|            | no.940 XID: 0xcb265880 (3408287872)  | Replay in no.1120 |
|            | no.969 XID: 0xcb265881 (3408287873)  | Replay in no.1122 |
|            | no.1022 XID: 0xcb265882 (3408287874) | Replay in no.1125 |
|            | no.1061 XID: 0xcb265883 (3408287875) | Replay in no.1127 |
|            | no.1094 XID: 0xcb265884 (3408287876) | Replay in no.1139 |

​						请求端 (示例)  ( no.523 )	Procedure: WRITE (7)	-->			
​						记录请求端 XID: 0xcb265875 (3408287861) 【标记等待对应响应端】--->

​						对应的NFS层    有 Filehandle 和 文件内容  Data: <DATA> 
​									Filehandle 来自 LOOKUP 或 CREATE( 这里是 CREATE ) 
​															记录过的 对应文件名和Filehandle	-->
​									NFS层 记录 Data: <DATA> 中有 文件内容	

```
WRITE 动作时 ， 传输文件内容在请求端 WRITE Call
特别说明 : 传大文件时，会分包多次传送 WRITE Call 

下面是 WRITE Call 时 ，nfs协议，部分特征说明
- Offset：写操作的开始位置，从该位置开始写入。
- Count：写入数据的字节数。
```

```
多包 传输时 拼包分析	---> 一个大文件 由多个 WRITE Call 对话传送，
												每个 WRITE Call 对话，由多个tcp拼包够成
												
由 nfs007.pcapng -> no.523 -> 分析如下图
no.523 记录了 no.493 ~ no.523 传送的一段 WRITE Call 完整对话
nfs 包结构部分 传送的 DATA 有 32768 字节

从 no.493 中内容分析  一段 WRITE Call 完整对话 --> 
 --> 	RPC 包头结构 + NFS 包头结构 + contents 传输文件内容部分 (32768 bytes)
 
no.493 的 payload 不足以 装载 传输文件内容
加上 之后的 no.493 , no.494 , no.495 ... no.523 的前 1112 字节，刚好满足 32768 bytes

no.523 还有 336 bytes 的内容
这部分通过 no.554 分析 
					前面剩下的 336 bytes 刚好是 下一个 WRITE Call 的一部分
					
no.523 后面的 336 bytes + 
								no.524 + no.525 .......+
															+ no.554 的前 776 bytes 

刚好够成一个完整的 WRITE Call 对话 --> 
     -->  RPC 包头结构 + NFS 包头结构 + contents 传输文件内容部分 (32768 bytes)

依次类推 直到 上面的每个 XID 都得到响应 为止
```

​						响应端 (示例)	( no.625 )	等待	XID: 0xcb265875 (3408287861) 	--->	
​						Status: NFS3_OK (0) 	--->	
​						写入成功
![image-20230423101032126](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423101032126.png)WRITE 传输文件 动作结束条件 ， 两个

1. 写入文件内容 ， 长度到达指定值
2. 长度 到达指定值 ，后还有 两个字节的 0x0000 防护，确保 文件写入完成

---

---

### nfs008.pcapng	( 已整理完)

nfs008.pcapng 抓包时的动作是 ， 本地挂载远程目录后，从远程下载   
		 "记录.docx"   
		"xunhuan-dabao.sh"	到本地

![image-20230420153815214](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230420153815214.png)

##### 文件传输过程分析	分析两文件下载过程

```
nfs3 传输文件时，一直以文件句柄为标记，写入数据 ，不使用文件名	； 
			要先获取	待传输文件 ，文件名和文件句柄的对应关系 ； 
						这样，落地文件时，才能确认 落地文件的文件名是什么 ； 
										在同一个nfs服务器，每个文件对应句柄 唯一 ； 
	
NFS协议中
XID是指交换标识符（Exchange Identifier），用于标识客户端和服务器之间的请求和响应之间的关系。
每个请求或响应都有一个唯一的XID
```

​				***<	分析 待传输文件		"记录.docx"	"xunhuan-dabao.sh"	下载过程	>***

***分析	下载过程	相关RPC指令***

​			**READDIRPLUS**	( no.110 )

​						请求端	Procedure: READDIRPLUS (17)	-->	
​						记录请求端 XID: 0xcb265a0f (3408288271)

​						响应端	( no. ) 等待	XID: 0xcb265a0f (3408288271)  	 --->
​						Status: NFS3_OK (0)	 --->	如果NFS3_OK ，接着， 获取 FileHandle 列表

| 文件名           |                           文件句柄                           | 文件句柄长度 | 文件句柄哈希( wireshark自制，nfs协议无此内容) |
| ---------------- | :----------------------------------------------------------: | ------------ | --------------------------------------------- |
| new              | ![image-20230421171205315](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421171205315.png) | 48           | 0x1ca0839b                                    |
| 记录.docx        | ![image-20230421171423040](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421171423040.png) | 48           | 0x7b34bfaa                                    |
| xunhuan-dabao.sh | ![image-20230421171615202](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421171615202.png) | 48           | 0xedae639a                                    |




​			**READ** (6)		( no.734 )		下载	"xunhuan-dabao.sh"

​						请求端	Procedure: READ (6)		-->
​						记录请求端 XID: 0xcb265a5a (3408288346)  		-->	【标记等待对应响应端】--->
​						根据	Filehandle 确定	下载文件	xunhuan-dabao.sh
​						**READ 的请求 只有句柄，没有文件名，想获取文件名需从别处获取**

![image-20230421172115550](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421172115550.png)

​										下载	xunhuan-dabao.sh
​						响应端	Status: NFS3_OK (0)		-->
​						XID: 0xcb265a5a (3408288346)	-->
​						对应的	NFS层    有 文件内容  Data : <DATA> 
![image-20230421173010015](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421173010015.png)

​			**READ** 			下载	"记录.docx"		

| READ (6) | READ Call                              | READ Replay       |
| -------- | -------------------------------------- | ----------------- |
|          | no.844	XID: 0xcb265a64 (3408288356) | Replay in no.918  |
|          | no.845	XID: 0xcb265a65 (3408288357) | Replay in no.971  |
|          | no.846	XID: 0xcb265a66 (3408288358) | Replay in no.1017 |
|          | no.847	XID: 0xcb265a67 (3408288359) | Replay in no.1075 |
|          | no.848	XID: 0xcb265a68 (3408288360) | Replay in no.1283 |
|          | no.849	XID: 0xcb265a69 (3408288361) | Replay in no.1419 |
|          | no.850	XID: 0xcb265a6a (3408288362) | Replay in no.1477 |
|          | no.851	XID: 0xcb265a6b (3408288363) | Replay in no.1523 |
|          | no.852	XID: 0xcb265a6c (3408288364) | Replay in no.1575 |
|          | no.853	XID: 0xcb265a6d (3408288365) | Replay in no.1623 |
|          | no.856	XID: 0xcb265a6e (3408288366) | Replay in no.1679 |
|          | no.861	XID: 0xcb265a6f (3408288367) | Replay in no.1129 |
|          | no.862	XID: 0xcb265a70 (3408288368) | Replay in no.1181 |
|          | no.863	XID: 0xcb265a71 (3408288369) | Replay in no.1233 |
|          | no.868	XID: 0xcb265a72 (3408288370) | Replay in no.1335 |
|          | no.869	XID: 0xcb265a73 (3408288371) | Replay in no.1367 |

```
拼接 传输文件时 应按照 XID 请求的先后顺序，将对应 READ Replay 传输内容拼接
因为nfs3 传输的 响应是乱序的  ，要根据请求的XID先后顺序 ，排序
```

```
多包 传输时 拼包分析	---> 一个大文件 由多个 READ Replay 对话传送，
												每个 READ Replay 对话，由多个tcp拼包够成
												
由 nfs008.pcapng -> no.918 -> 分析如下图
no.918 记录了 no.864 ~ no.918 传送的一段 READ Replay 完整对话
nfs 包结构部分 传送的 DATA 有 32768 字节

从 no.864 中内容分析  一段 READ Replay 完整对话 --> 
 --> 	RPC 包头结构 + NFS 包头结构 + contents 传输文件内容部分 (32768 bytes)
 
no.864 的 payload 不足以 装载 传输文件内容
则加上 之后的 no.866 , no.870 , no.872 ... no.918 的前 1044 字节，刚好满足 32768 bytes

no.918 还有 404 bytes 的内容 未被 第一个 READ Replay 使用 ！！
这部分通过 no.971 分析 
					前面剩下的 404 bytes 刚好是 no.971 对应 READ Replay 的一部分
					
no.918 后面的 404 bytes + 
								no.920 + no.922 .......+
															+ no.971 的前 640 bytes 

刚好够成一个完整的 READ Replay 对话 --> 
     -->  RPC 包头结构 + NFS 包头结构 + contents 传输文件内容部分 (32768 bytes)

依次类推 直到 上面的每个 XID 都得到响应 为止
```

![image-20230421161742616](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421161742616.png)

READ 传输文件 动作结束条件 ， 两个

1. READ Replay 中 EOF 值为yes

2. 对句柄 a 的所有请求，都得到响应

   ![image-20230423172503525](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423172503525.png)

---

---

### nfs009.pcapng	(配合 nfs008.pcapng 参考用，抓包动作相似)

nfs009.pcapng 抓包时的动作是 ， 本地挂载远程目录后，从远程下载    
		(记录.docx)  
 		(xunhuan-dabao.sh)
		(nfs 协议分析.md)	到本地

![image-20230421165210601](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230421165210601.png)

---

### nfs010.pcapng ( 经2023.7.3 验证 可以传输落地文件 )

nfs010.pcapng抓包动作是 ， 挂载后，直接上传一批文件， 这些文件在 nfs服务器中已有，当下只是覆盖传输

( 
管理系统测试记录.docx  
记录.txt  
ftp_weakpwd_2.pcapng  
note.txt 
)

[hash (CRC-32): 0x623b3270]
[hash (CRC-32): 0xecb43593]
[hash (CRC-32): 0x201e350d]
[hash (CRC-32): 0x2adb3c14]

![image-20230523140950697](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230523140950697.png)

传输的文件都打包在 nfs010.tgz 中

---

### nfs011.pcapng  ( 经2023.7.3 验证 可以传输落地文件 )

和 nfs010.pcapng 传输的文件相同 ， 区别 ， 这些文件在 nfs服务器中本来没有 ， 当下是创建传输

---

### nfs012.pcapng ( ok )

没做特别的操作，挂载 -> ls 查看目录内容 -> 卸载挂载目录

---

### nfs006.pcapng

nfs006.pcapng 抓包时的动作是 ， 本地挂载远程目录后，在本地 ，点开这俩文件直接读( READ 其内容)

![双击点开这两个文件](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230419181103707.png)

##### 文件传输过程分析

​	RPC协议

​			READDIRPLUS	( no.107 )

​						请求端	Procedure: READDIRPLUS (17)	-->	
​						记录请求端 XID: 0xcb26566f (3408287343) 

​						响应端	( no.110 ) 等待	XID: 0xcb26566f (3408287343)	 --->
​						Status: NFS3_OK (0)	 --->	如果正确，进下一步， 获取 FileHandle 列表	

| 文件名   | 文件句柄                                                     | 文件句柄长度 | 文件句柄哈希( wireshark自制 ，nfs协议无此内容 ) |
| -------- | ------------------------------------------------------------ | ------------ | ----------------------------------------------- |
| nfs.pcap | ![image-20230423165643784](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423165643784.png) | 48           | 0x0fa005b0                                      |
| qq.txt   | ![image-20230423165908527](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423165908527.png) | 48           | 0xc56e733c                                      |
|          |                                                              |              |                                                 |

​		READ (6)		( no.600 )

​						请求端	Procedure: READ (6)		-->
​						记录请求端 XID: 0xcb2656e5 (3408287461)		-->
​						根据	Filehandle 确定

![image-20230423170515511](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423170515511.png)

​						响应端	( no.601 ) Status: NFS3_OK (0)		-->
![image-20230423170821917](/Users/zhangsiyi/Library/Application Support/typora-user-images/image-20230423170821917.png)

---

```
 //	rpc请求中 Procedure 就是nfs4 操作指令的opcode
    {   NFS4_OP_ACCESS,                "ACCESS"  },
    {   NFS4_OP_CLOSE,                 "CLOSE"  },
    {   NFS4_OP_COMMIT,                "COMMIT"  },
    {   NFS4_OP_CREATE,                "CREATE"  },
    {   NFS4_OP_DELEGPURGE,            "DELEGPURGE"  },
    {   NFS4_OP_DELEGRETURN,           "DELEGRETURN"  },
    {   NFS4_OP_GETATTR,               "GETATTR"  },
    {   NFS4_OP_GETFH,                 "GETFH"  },
    {   NFS4_OP_LINK,                  "LINK"  },
    {   NFS4_OP_LOCK,                  "LOCK"  },
    {   NFS4_OP_LOCKT,                 "LOCKT"  },
    {   NFS4_OP_LOCKU,                 "LOCKU"  },
    {   NFS4_OP_LOOKUP,                "LOOKUP"  },
    {   NFS4_OP_LOOKUPP,               "LOOKUPP"  },
    {   NFS4_OP_NVERIFY,               "NVERIFY"  },
    {   NFS4_OP_OPEN,                  "OPEN"  },
    {   NFS4_OP_OPENATTR,              "OPENATTR"  },
    {   NFS4_OP_OPEN_CONFIRM,          "OPEN_CONFIRM"  },
    {   NFS4_OP_OPEN_DOWNGRADE,        "OPEN_DOWNGRADE"  },
    {   NFS4_OP_PUTFH,                 "PUTFH"  },
    {   NFS4_OP_PUTPUBFH,              "PUTPUBFH"  },
    {   NFS4_OP_PUTROOTFH,             "PUTROOTFH"  },
    {   NFS4_OP_READ,                  "READ"  },
    {   NFS4_OP_READDIR,               "READDIR"  },
    {   NFS4_OP_READ,                  "READ"  },
    {   NFS4_OP_READDIR,               "READDIR"  },
    {   NFS4_OP_READLINK,              "READLINK"  },
    {   NFS4_OP_REMOVE,                "REMOVE"  },
    {   NFS4_OP_RENAME,                "RENAME"  },
    {   NFS4_OP_RENEW,                 "RENEW"  },
    {   NFS4_OP_RESTOREFH,             "RESTOREFH"  },
    {   NFS4_OP_SAVEFH,                "SAVEFH"  },
    {   NFS4_OP_SECINFO,               "SECINFO"  },
    {   NFS4_OP_SETATTR,               "SETATTR"  },
    {   NFS4_OP_SETCLIENTID,           "SETCLIENTID"  },
    {   NFS4_OP_SETCLIENTID_CONFIRM,   "SETCLIENTID_CONFIRM"  },
    {   NFS4_OP_VERIFY,                "VERIFY"  },
    {   NFS4_OP_WRITE,                 "WRITE"  },
    {   NFS4_OP_RELEASE_LOCKOWNER,     "RELEASE_LOCKOWNER"  },
    {   NFS4_OP_BACKCHANNEL_CTL,       "BACKCHANNEL_CTL"  },
    {   NFS4_OP_BIND_CONN_TO_SESSION,  "BIND_CONN_TO_SESSION"  },
    {   NFS4_OP_EXCHANGE_ID,           "EXCHANGE_ID"  },
    {   NFS4_OP_CREATE_SESSION,        "CREATE_SESSION"  },
    {   NFS4_OP_DESTROY_SESSION,       "DESTROY_SESSION"  },
    {   NFS4_OP_FREE_STATEID,          "FREE_STATEID"  },
    {   NFS4_OP_GET_DIR_DELEGATION,    "GET_DIR_DELEGATION"  },
    {   NFS4_OP_GETDEVINFO,            "GETDEVINFO"  },
    {   NFS4_OP_GETDEVLIST,            "GETDEVLIST"  },
    {   NFS4_OP_LAYOUTCOMMIT,          "LAYOUTCOMMIT"  },
    {   NFS4_OP_LAYOUTGET,             "LAYOUTGET"  },
    {   NFS4_OP_LAYOUTRETURN,          "LAYOUTRETURN"  },
    {   NFS4_OP_SECINFO_NO_NAME,       "SECINFO_NO_NAME"  },
    {   NFS4_OP_SEQUENCE,              "SEQUENCE"  },
    {   NFS4_OP_SET_SSV,               "SET_SSV"  },
    {   NFS4_OP_TEST_STATEID,          "TEST_STATEID"  },
    {   NFS4_OP_WANT_DELEGATION,       "WANT_DELEG"  },
    {   NFS4_OP_DESTROY_CLIENTID,      "DESTROY_CLIENTID"  },
    {   NFS4_OP_RECLAIM_COMPLETE,      "RECLAIM_COMPLETE"  },
    {   NFS4_OP_ALLOCATE,              "ALLOCATE"  },
    {   NFS4_OP_COPY,                  "COPY"  },
    {   NFS4_OP_COPY_NOTIFY,           "COPY_NOTIFY"  },
    {   NFS4_OP_DEALLOCATE,            "DEALLOCATE"  },
    {   NFS4_OP_IO_ADVISE,             "IO_ADVISE"  },
    {   NFS4_OP_LAYOUTERROR,           "LAYOUTERROR"  },
    {   NFS4_OP_LAYOUTSTATS,           "LAYOUTSTATS"  },
    {   NFS4_OP_OFFLOAD_CANCEL,        "OFFLOAD_CANCEL"  },
    {   NFS4_OP_OFFLOAD_STATUS,        "OFFLOAD_STATUS"  },
    {   NFS4_OP_READ_PLUS,             "READ_PLUS"  },
    {   NFS4_OP_SEEK,                  "SEEK"  },
    {   NFS4_OP_WRITE_SAME,            "WRITE_SAME"  },
    {   NFS4_OP_CLONE,                 "CLONE"  },
    {   NFS4_OP_GETXATTR,              "GETXATTR"  },
    {   NFS4_OP_SETXATTR,              "SETXATTR"  },
    {   NFS4_OP_GETXATTR,              "GETXATTR"  },
    {   NFS4_OP_SETXATTR,              "SETXATTR"  },
    {   NFS4_OP_LISTXATTRS,            "LISTXATTRS"  },
    {   NFS4_OP_REMOVEXATTR,           "REMOVEXATTR"  },
    {   NFS4_OP_ILLEGAL,               "ILLEGAL"  },
    {   0, NULL  }
```

#### nfs协议指令类型功能介绍

```
Wireshark分析nfs协议

Procedure: NULL (0) 
什么意思

"Procedure: NULL (0)" 表示一个空过程或空调用。
当客户端发送一个空过程调用时，它会向服务器发送一个空的请求，并期望服务器在响应中返回一个空的结果。
因此，“Procedure: NULL (0)” 表示该消息是一个空的过程调用，没有实际的操作或参数传递。通常用于测试连接或确认服务器是否在运行。

```

```
Wireshark分析nfs协议

Procedure: FSINFO (19)
什么意思

“Procedure: FSINFO (19)” 表示一个文件系统信息查询的过程调用。

当客户端需要获取服务器上特定文件系统的信息时，它会向服务器发送一个 FSINFO 过程调用。此过程调用的参数包括文件系统标识符（Filesystem Identifier），以及一个布尔值，用于指示是否需要获取文件系统属性（Filesystem Properties）。

服务器将在响应消息中返回与文件系统相关的信息，包括文件系统标识符、文件系统属性以及可用空间等。这个过程调用可以帮助客户端更好地理解服务器上文件系统的结构和状态，以便更有效地管理文件系统。
```

```
wireshark分析

Procedure: ACCESS (4)
什么意思

"Procedure: ACCESS (4)" 表示一个访问权限查询的过程调用。

当客户端需要确定对某个文件或目录的访问权限时，它会向服务器发送一个 ACCESS 过程调用。该过程调用的参数包括文件或目录的句柄以及所需的访问权限标志。

服务器将在响应消息中返回客户端具有的实际访问权限。这个过程调用可以帮助客户端确定其能否读取、写入或执行指定的文件或目录。

```

```
wireshark 分析 nfs协议时 

Procedure: GETATTR (1)

什么意思

这是NFS（Network File System）协议中的一个过程（Procedure），即“获取属性”（GETATTR），使用过程编号（Procedure number）为1。

这个过程用于请求获取指定文件或目录的属性信息。在Wireshark中分析NFS协议时，可以看到每个NFS过程的详细信息，包括过程号、请求参数和响应参数等。

```

```
Network File System, LOOKUP Reply  Error: NFS3ERR_NOENT
Status: NFS3ERR_NOENT (2)

什么意思
这个信息表示 NFS 客户端执行 LOOKUP 操作时出现了错误，错误代码是 NFS3ERR_NOENT，即找不到文件或目录。这通常意味着客户端尝试查找一个不存在的文件或目录。

```

```
wireshark分析 nfs3协议时
Procedure: PATHCONF (20)
什么意思

在NFSv3协议中，PROCEDURE PATHCONF（20）是一种客户端向服务器请求获取特定NFS文件系统的属性信息的操作。具体来说，该过程可用于检索有关文件系统的以下信息：
max file size（文件的最大尺寸）
NFS服务器上支持的最大文件名长度
NFS服务器上支持的最大路径名长度
NFS服务器上支持的硬链接的最大数量
NFS服务器上支持的文件系统属性标志的位掩码
客户端可以使用此信息来优化其文件访问模式以获得更好的性能或确保其操作不会超出服务器支持的限制。
```

```
wireshark分析 nfs3协议时
Procedure: SETATTR (2)
什么意思

"Procedure: SETATTR (2)" 表示捕获的数据包是 NFSv3 协议中的 SETATTR 过程，其中 "Procedure" 表示该数据包包含一个过程，"SETATTR" 表示该过程是 SETATTR 过程，"2" 表示该过程的过程号是 2。NFSv3 协议是 Network File System Version 3，用于在计算机网络中共享文件系统。

SETATTR 过程用于将文件或目录的属性设置为指定的值，例如修改文件的所有者、修改文件的访问时间等。
```

```
Wireshark分析nfs协议

Procedure: REMOVE (12)
什么意思

Procedure REMOVE（12）是用于删除指定文件或目录的操作。该操作会将文件或目录从文件系统中删除，并且如果被删除的是目录，则会将目录下的所有文件和子目录也一并删除。

在 Wireshark 中，可以通过捕获和分析 NFS 协议的数据包来查看客户端和服务器之间的通信，其中 Procedure REMOVE（12）对应的是 NFS 协议中的一种操作。可以从数据包中的字段信息中获取更多有关该操作的详细信息，例如被删除的文件或目录的名称、文件系统的路径、权限等信息。
```

```
Wireshark分析nfs协议

Procedure: COMMIT (21)

什么意思

COMMIT过程用于提交客户端对文件的修改并将其写入到服务器上的持久存储设备中。
当客户端想要确保修改操作已成功完成时，会使用COMMIT过程向服务器发送一个请求。服务器会将缓存中尚未写入持久存储设备中的数据强制刷写到磁盘上，然后响应客户端请求。该过程可以确保数据的完整性，避免数据的丢失或损坏。
```

```
Wireshark分析nfs协议

Procedure: READDIRPLUS (17)

用于读取一个目录并返回其内容，包括文件属性和文件句柄。 
READDIRPLUS过程会读取一个目录，并在每个目录项中返回文件的属性（如文件类型、大小、修改时间等）和文件句柄，以便客户端可以使用它来进一步操作文件。此外，READDIRPLUS过程还可以返回目录项的属性，例如创建时间和最后访问时间。
```

```
Wireshark分析nfs协议

Procedure: FSSTAT (18)

什么意思

FSSTAT 过程用于返回与文件系统相关的信息。

该过程将获取有关文件系统的信息，并将其作为 statfs 结构返回给客户端。

其中，statfs 结构包含有关文件系统的信息，如块大小、总块数、空闲块数、总文件数等。这些信息对于客户端来说是有用的，因为它们可以帮助客户端优化文件系统上的文件访问。


```

### nfs001.pcapng 报文格式分析

no.218	Network File System, LOOKUP Call DH: 0xac45443d/mount.sh
what
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: mount.sh
        length: 8
        contents: mount.sh	

---

no.221	Network File System, LOOKUP Reply FH: 0x9e185787
Status: NFS3_OK (0)
object
    length: 28
    [hash (CRC-32): ]
    FileHandle: 4e5800008217268b00000001000000000800000040d57b0000000000

---

---

no.230	Network File System, LOOKUP Call DH: 0xac45443d/.mount.sh.swp
what
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swp
        length: 13
        contents: .mount.sh.swp
        fill bytes: opaque data

---

no.233	Network File System, LOOKUP Reply  Error: NFS3ERR_NOENT
Status: NFS3ERR_NOENT (2)

---

---

no.234	Network File System, CREATE Call DH: 0xac45443d/.mount.sh.swp Mode: EXCLUSIVE
where
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swp
        length: 13
        contents: .mount.sh.swp
        fill bytes: opaque data

---

no.237	Network File System, CREATE Reply
Status: NFS3_OK (0)
obj
    handle_follow: value follows (1)
    handle
        length: 28
        [hash (CRC-32): 0xd77f0464]
        FileHandle: 4e5800008217268b00000001000000000800000071d57b0000000000

---

---

no.242	Network File System, LOOKUP Call DH: 0xac45443d/.mount.sh.swx
what
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swx
        length: 13
        contents: .mount.sh.swx
        fill bytes: opaque data

---

no.245	Network File System, LOOKUP Reply  Error: NFS3ERR_NOENT
Status: NFS3ERR_NOENT (2)

---

---

no.246	Procedure: CREATE (8)
where
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swx
        length: 13
        contents: .mount.sh.swx
        fill bytes: opaque data

---

no.249	Status: NFS3_OK (0)
obj
    handle_follow: value follows (1)
    handle
        length: 28
        [hash (CRC-32): 0x59f00387]
        FileHandle: 4e5800008217268b00000001000000000800000072d57b0000000000

---

---

no.254	REMOVE Call DH: 0xac45wo443d/.mount.sh.swx
object
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swx
        length: 13
        contents: .mount.sh.swx
        fill bytes: opaque data

---

no.257	Status: NFS3_OK (0)

---

---

no.258	REMOVE Call DH: 0xac45443d/.mount.sh.swp
object
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swp
        length: 13
        contents: .mount.sh.swp
        fill bytes: opaque data

---

no.261	Status: NFS3_OK (0)

---

---

no.262	CREATE Call DH: 0xac45443d/.mount.sh.swp Mode: EXCLUSIVE
where
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: .mount.sh.swp
        length: 13
        contents: .mount.sh.swp
        fill bytes: opaque data

---

no.265	Status: NFS3_OK (0)
obj
    handle_follow: value follows (1)
    handle
        length: 28
        [hash (CRC-32): 0x955a0319]
        FileHandle: 4e5800008217268b00000001000000000800000073d57b0000000000

---

---

no.274	WRITE Call FH: 0x955a0319 Offset: 0 Len: 4096 FILE_SYNC
file
    length: 28
    [hash (CRC-32): 0x955a0319]
    FileHandle: 4e5800008217268b00000001000000000800000073d57b0000000000

---

no.279	Status: NFS3_OK (0)

---

---

no.288	READ Call FH: 0x9e185787 Offset: 0 Len: 4096
file
    length: 28
    [hash (CRC-32): 0x9e185787]
    FileHandle: 4e5800008217268b00000001000000000800000040d57b0000000000

---

no.291	READ Reply Len: 81
Status: NFS3_OK (0)
Data: <DATA>
    length: 81
    contents: <DATA>
    fill bytes: opaque data

---

---

no.298	WRITE Call FH: 0x955a0319 Offset: 0 Len: 4096 UNSTABLE
file
    length: 28
    [hash (CRC-32): 0x955a0319]
    FileHandle: 4e5800008217268b00000001000000000800000073d57b0000000000
Data: <DATA>
    length: 4096
    contents: <DATA>

---

no.303	WRITE Reply Len: 4096 UNSTABLE
Status: NFS3_OK (0)

---

---

no.318	LOOKUP Call DH: 0xac45443d/4913
what
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: 4913
        length: 4
        contents: 4913 

---

no.321	LOOKUP Reply  Error: NFS3ERR_NOENT
Status: NFS3ERR_NOENT (2)

---

---

no.322	<span style="color:green">CREATE Call DH: 0xac45443d/4913 Mode: EXCLUSIVE</span>
where
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: 4913
        length: 4
        contents: 4913

---

no.325	<font color="red">CREATE Reply</font>
Status: NFS3_OK (0)

---

---

no.334	REMOVE Call DH: 0xac45443d/4913
object
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: 4913
        length: 4
        contents: 4913

---

no.337	REMOVE Reply
Status: NFS3_OK (0)

---

---

no.338	LOOKUP Call DH: 0xac45443d/mount.sh~
what
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: mount.sh~
        length: 9
        contents: mount.sh~
        fill bytes: opaque data

---

no.341	LOOKUP Reply  Error: NFS3ERR_NOENT
Status: NFS3ERR_NOENT (2)

---

---

no.342	RENAME Call From DH: 0xac45443d/mount.sh To DH: 0xac45443d/mount.sh~

---

no.345	RENAME Reply
Status: NFS3_OK (0)

---

---

no.346	LOOKUP Call DH: 0xac45443d/mount.sh
what
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: mount.sh
        length: 8
        contents: mount.sh

---

no.349	LOOKUP Reply  Error: NFS3ERR_NOENT
Status: NFS3ERR_NOENT (2)

---

---

no.350	CREATE Call DH: 0xac45443d/mount.sh Mode: UNCHECKED
where
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: mount.sh
        length: 8
        contents: mount.sh

---

no.353	CREATE Reply
Status: NFS3_OK (0)

---

---

no.358	WRITE Call FH: 0x80d0112b Offset: 0 Len: 91 FILE_SYNC
file
    length: 28
    [hash (CRC-32): 0x80d0112b]
    FileHandle: 4e5800008217268b0000000100000000080000007dd57b0000000000
Data: <DATA>
    length: 91
    contents: <DATA>
    fill bytes: opaque data

---

no.361	WRITE Reply Len: 91 FILE_SYNC
Status: NFS3_OK (0)

---

---

no.366	REMOVE Call DH: 0xac45443d/mount.sh~
object
    dir
        length: 28
        [hash (CRC-32): 0xac45443d]
        FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
    Name: mount.sh~
        length: 9
        contents: mount.sh~
        fill bytes: opaque data

---

no.369	REMOVE Reply
Status: NFS3_OK (0)

---

---

no.374	WRITE Call FH: 0x955a0319 Offset: 0 Len: 4096 FILE_SYNC
file
        length: 28
        [hash (CRC-32): 0x955a0319]
        FileHandle: 4e5800008217268b00000001000000000800000073d57b0000000000
    offset: 0
    count: 4096
    Stable: FILE_SYNC (2)
Data: <DATA>
        length: 4096
        contents: <DA

---

no.379	WRITE Reply Len: 4096 FILE_SYNC
Status: NFS3_OK (0)

---

---

no.380	REMOVE Call DH: 0xac45443d/.mount.sh.swp
    object
        dir
            length: 28
            [hash (CRC-32): 0xac45443d]
            FileHandle: 4e5800008217268b00000001000000000800000055af690000000000
        Name: .mount.sh.swp
            length: 13
            contents: .mount.sh.swp
            fill

---

no.383	REMOVE Reply
Status: NFS3_OK (0)

---

---

### 关于nfs协议的发送者和接受者

```
nfs3 协议能区分接受者和发送者 ， 得到他们的名字 么

在NFSv3协议中，请求和响应消息中并没有直接包含发送者和接收者的名称，只有一些标识符可以用于将请求和响应消息相关联。例如，每个请求消息和相应消息都有一个"文件句柄"，用于指示正在请求的文件或目录。这个文件句柄通常是由NFS服务器返回给客户端的，因此可以将其视为服务器指定的标识符。此外，在NFSv3协议中，客户端和服务器之间的通信是通过RPC（远程过程调用）协议进行的，因此每个RPC消息都有一个发送者的IP地址和端口号以及接收者的IP地址和端口号。虽然这些信息不能直接用于识别发送者或接收者的名称，但它们可以用于确定RPC消息的源和目标。
```

```
nfs4 协议能区分接受者和发送者 ， 得到他们的名字 么

在NFSv4协议中，每个客户端和服务器都有一个唯一的“client ID”或“server ID”，可以通过这个ID来区分发送者和接收者。但是这个ID并不能直接映射到名称，需要通过一些其他的操作，比如通过RPCBIND协议来查询对应的主机名。因此，虽然NFSv4协议可以区分发送者和接收者，但不能直接得到他们的名字。
```

---

---



[TOC]



---

```

```

