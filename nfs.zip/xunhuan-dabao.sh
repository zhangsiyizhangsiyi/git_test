
echo "for i in \`ls *.mp4\`; do tar -jcvf $i.tar.bz2 $i ;done"
